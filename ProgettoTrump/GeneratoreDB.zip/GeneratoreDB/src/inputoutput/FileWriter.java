package inputoutput;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class FileWriter {
private BufferedWriter writer = null;
	
	public FileWriter(String path) throws FileNotFoundException {
		setPath(path);
	}
	
	public void setPath(String path) throws FileNotFoundException {
		writer = new BufferedWriter(new OutputStreamWriter(
				new FileOutputStream(new File(path))));
	}
	
	public BufferedWriter getWriter() {
		return this.writer;
	}
}
