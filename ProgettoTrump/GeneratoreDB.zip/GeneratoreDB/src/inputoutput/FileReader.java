package inputoutput;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

public class FileReader {

	private BufferedReader reader = null;
	
	public FileReader(String path) throws FileNotFoundException {
		setPath(path);
	}
	
	public void setPath(String path) throws FileNotFoundException {
		reader = new BufferedReader(new InputStreamReader(
				new FileInputStream(new File(path))));
	}
	
	public BufferedReader getReader() {
		return this.reader;
	}
}
