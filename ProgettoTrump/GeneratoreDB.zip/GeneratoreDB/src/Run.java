import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import inputoutput.*;

public class Run {

	public static void main(String[] args) {
		
		/* Input per il numero dei record: 100/1000/10000 etc */
		Scanner getInput = new Scanner(System.in);
		System.out.println("Inserisci numero record: ");
		
		int nOfRecords = getInput.nextInt();
		getInput.close();
		
		/*--------------------------------------------------*/
		
		boolean isOK = true; //serve per evitare di continuare in caso di errori
		
		/* Leggi i file .txt e crea le strutture dati */
		FileReader reader = null;
		String data = null;
		List<String> names = null, surnames = null, connections = null, organizations = null;
		
		try {
			//creo l'oggetto FileReader e passo al costruttore il path del file
			//in seguito creo l'array list e leggo finch� ci sono file
			
			//questo processo lo ripeter� altre volte con gli altri files
			reader = new FileReader("bin\\data\\nomi.txt");
			names = new ArrayList<>();
			
			while((data = reader.getReader().readLine()) != null) {
				names.add(data);
			}
			
			reader.setPath("bin\\data\\cognomi.txt");
			surnames = new ArrayList<>();
			
			while((data = reader.getReader().readLine()) != null) {
				surnames.add(data);
			}
			
			reader.setPath("bin\\data\\connection.txt");
			connections = new ArrayList<>();
			
			while((data = reader.getReader().readLine()) != null) {
				connections.add(data);
			}
			
			reader.setPath("bin\\data\\organization.txt");
			organizations = new ArrayList<>();
			
			while((data = reader.getReader().readLine()) != null) {
				organizations.add(data);
			}			
		} catch (FileNotFoundException e) { //gestisco gli errori
			e.printStackTrace();
			isOK = false;
		} catch (IOException e) {
			e.printStackTrace();
			isOK = false;
		} finally { //chiudo il canale di lettura 
			try {
				reader.getReader().close();
			} catch (IOException e) {}
		}
		
		if (isOK) {
			/* Core */
			FileWriter writer = null;
			Iterator<String> it = null;
			Set<String> record = new HashSet<>();
			Random rand = new Random();
			int index1 = -1, index2 = -1;
			
			//ciclicamente estraggo un numero randomico che va da 0 a 1
			//con lo 0 indichiamo le persone, mentre con 1 indichiamo le organizzazioni
			
			//in base al numero estratto, controllo se il Set (denomimanto record) contiene gi�
			//la stringa. 
			//La stringa � composta da una parte impostata manualmente (Organization o People)
			//e dall'estrazione randomica di un nome e cognome (nel caso in cui uscisse lo 0) 
			//oppure del nome dell'organizzazione (nel caso in cui uscisse 1)
			
			//se la stringa non � presente all'interno del Set allora la aggiungo altrimenti
			//decremento la variabile contatore per non sprecare il ciclo in caso di doppioni
			for (int j = 0; j < nOfRecords * 2; j++) {
				if (rand.nextInt(2) == 1) {
					index1 = rand.nextInt(organizations.size());
					if (!record.contains("Organization," + organizations.get(index1))) {
						record.add("Organization," + organizations.get(index1));
					} else j--;
				} else {
					index1 = rand.nextInt(names.size());
					index2 = rand.nextInt(surnames.size());
					if (!record.contains("Person," + names.get(index1) + " " + surnames.get(index2))) {
						record.add("Person," + names.get(index1) + " " + surnames.get(index2));
					} else j--;
				}
			}
			
			//Qui creo un nuovo oggetto FileWriter e passo come path il nome del
			//file che voglio creare
			
			//scrivo l'header
			
			//ottengo l'iterator del Set
			//l'oggetto iterator consente di iterare gli elementi 
			//presenti nei set e in altre strutture dati (studialo anche per 
			//programmazione 2)
			
			//creo due array di stringhe perch� mi serviranno pi� avanti (capirai dopo)
			
			//con il metodo split divido la stringa in due singoli elementi che 
			//vengono memorizzati dall'array per portervi accedere in seguito
			
			//finch� ci sono elementi nel set allora compongo la stringa connection,
			//la quale serve per scegliere la connessione tra le due entit�, in modo 
			//randomico
			
			//genero il sito web. Ho preferito utilizzare soltanto documentcloud per 
			//semplicare il lavoro. Come puoi vedere viene generato un numero randomico 
			//compreso da 0 fino a quel numerone li + il nome dell'entit� A che si trova
			//nell'array splittato in precedenza + il nome dell'entit� B + .html
			//con il meotodo replaceAll pulisco gli eventuali caratteri speciali sostituendoli
			//con il carattere - e con il metodo toLowerCase converto l'indirizzo in 
			//minuscolo
			
			//fatto questo con l'oggetto writer scrivo tutto sul file e alla fine 
			//chiudo il canale
			try {
				writer = new FileWriter("bin\\data\\dataset.csv");
				it = record.iterator();
				
				/* Writer header*/
				writer.getWriter().write("Entity A Type,Entity A,Entity B Type,Entity B,Connection,Source(s)" + "\r\n");
				
				String[] entityA = null, entityB = null;
				String webSite = null, connection = null;
				
				while (it.hasNext()) {
					entityA = it.next().split(",");
					entityB = it.next().split(",");
					
					connection = connections.get(rand.nextInt(connections.size()));
					
					webSite = "https://www.documentcloud.org/documents/"
							+ rand.nextInt(9999999) + "-" + entityA[1] + "-" 
							+ entityB[1] + ".html";
					
					webSite = webSite.replaceAll("[\\'\\& \\?]", "-");
					
					webSite = webSite.toLowerCase();
					
					writer.getWriter().write(entityA[0] + ","  + entityA[1] + 
							"," + entityB[0] + "," + entityB[1] + "," + connection + 
							"," + webSite + "\r\n");
				}				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try {
					writer.getWriter().close();
				} catch (IOException e) {}
			}
		}
	}

}
